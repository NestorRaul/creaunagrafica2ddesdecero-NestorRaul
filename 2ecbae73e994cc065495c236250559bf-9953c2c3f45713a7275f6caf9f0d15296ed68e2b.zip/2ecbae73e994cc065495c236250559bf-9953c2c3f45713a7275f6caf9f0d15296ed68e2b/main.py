import numpy as np
import pylab as pl
x = [1,2,3,4]
y = [8.5,8.5,8.0,8.6]
pl.plot(x, y, 'rp')
pl.savefig('promedios.png')